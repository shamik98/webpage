document.addEventListener("DOMContentLoaded", function () {
  const boxes = document.querySelectorAll(".box");

  boxes.forEach(function (box) {
    const radio = box.querySelector('input[type="radio"]');
    const content = box.querySelector(".box-content");
    const colorSelect = box.querySelector('select[id$="-color"]');
    const sizeSelect = box.querySelector('select[id$="-size"]');

    radio.addEventListener("click", function (e) {
      e.stopPropagation();

      if (content.style.display === "block") {
        closeBox(box);
      } else {
        closeAllBoxes();
        content.style.display = "block";
        box.style.backgroundColor = "yellow";
      }
    });

    colorSelect.addEventListener("change", function () {
      //   content.style.backgroundColor = colorSelect.value;
      console.log(`Selected color: ${colorSelect.value}`);
    });

    sizeSelect.addEventListener("change", function () {
      console.log(`Selected size: ${sizeSelect.value}`);
    });
  });

  function closeBox(box) {
    const content = box.querySelector(".box-content");
    const colorSelect = box.querySelector('select[id$="-color"]');
    const sizeSelect = box.querySelector('select[id$="-size"]');

    content.style.display = "none";
    colorSelect.value = "red";
    sizeSelect.value = "small";
    box.style.backgroundColor = "rgb(170, 255, 0)";
  }

  function closeAllBoxes() {
    boxes.forEach(function (box) {
      closeBox(box);
    });
  }

  document.addEventListener("click", function (e) {
    if (!e.target.closest(".box")) {
      closeAllBoxes();
    }
  });
});
